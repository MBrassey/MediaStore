const ethers = require('ethers');
const { AdaptiveCards } = require ('@microsoft/adaptivecards-tools');
const { WebhookTarget } = require('./webHookTarget.js');
const { infoLogger } = require('~utils/logger');
const cron = require('node-cron');
const fs = require('fs');
const { jsPDF } = require('jspdf');
require('dotenv').config();

const cvxWalletAddress = process.env.CONVEX_WALLET;
const maticWallet = process.env.MATIC_WALLET;
const loadJSON = (pathname) => JSON.parse(fs.readFileSync(pathname));
const convex_pool25_extra_rewardsabi = loadJSON('./abi/convex_pool25_extra_rewards_abi.json');
const stETH_ETH_pool_abi = loadJSON('./abi/stETH_ETH_pool_abi.json');
const DECIMALS = 18;
const lido_curve_farm_abi = loadJSON('./abi/lido_curve_farm_abi.json');
const aave_staking_abi = loadJSON('./abi/aave_staking_abi.json');
const ausdcAbi = loadJSON('./abi/aUSDC_abi.json');
const cvxRewards_abi = loadJSON('./abi/cvx_rewards_abi.json');
const matc_staking_abi = loadJSON('./abi/matic_staking.json');
const stakedEth_abi = loadJSON('./abi/stakedEth_LDO_abi.json');
const spark_abi = loadJSON('./abi/spark_abi.json');
const hlofSpark = process.env.HLOF_SPARK_WALLET;
const blurBid_abi = loadJSON('./abi/blur_abi.json');
const compoundRewardsAbi = loadJSON('./abi/compound_rewards_abi.json');
const hvmfETHStakingWallet = process.env.HVMF_LIDO_STAKED_ETH_WALLET;
const hlofETHStakingWallet = process.env.HLOF_LIDO_STAKED_ETH_WALLET;
const bendDAO_abi = loadJSON('./abi/bendDAO_abi.json');
const apeIds = process.env.APE_IDS.split(',');

const aaveWalletAddress = process.env.AAVE_WALLET;
const ausdcWalletLOF = process.env.AUSDC_WALLET_LOF;
const ausdcWalletHVMF = process.env.AUSDC_WALLET_HVMF;
const cusdcWalletLOF = process.env.CUSDC_WALLET_LOF;
const cusdcWalletHVMF = process.env.CUSDC_WALLET_HVMF;
const aaveAbi = loadJSON('./abi/aave_abi.json');
const compoundAbi = loadJSON('./abi/compound_abi.json');
const origAWETHBal = process.env.ORIG_AWETH || 0;
const hvmfOrigStakedEthBal = process.env.HVMF_ORIG_stETH || 0;
const hlofOrigStakedEthBal = process.env.HLOF_ORIG_stETH || 0;

const blurWallets = process.env.BLUR_WALLETS.split(',');

const template = loadJSON('./adaptiveCards/notification-default.json');
const webhookUrl = process.env.WEBHOOK;

cron.schedule('59 59 23 * * *', () => {
	infoLogger.debug('Running wallet scan');
	refreshPriceData();
}, {
	timezone: 'UTC',
	utcOffset: 0,
});

async function refreshPriceData() {
	const provider = new ethers.EtherscanProvider('homestead', process.env.ETHERSCAN_API_KEY);

	const convex_pool25_extra_rewardscontract = new ethers.Contract('0x008aEa5036b819B4FEAEd10b2190FBb3954981E8', convex_pool25_extra_rewardsabi, provider);

	const stETH_ETH_pool = new ethers.Contract('0x0A760466E1B4621579a82a39CB56Dda2F4E70f03', stETH_ETH_pool_abi, provider);

	const rewardToken = await convex_pool25_extra_rewardscontract.rewardToken();
	const stakedBlanace = await convex_pool25_extra_rewardscontract.balanceOf(cvxWalletAddress);
	const earned = await convex_pool25_extra_rewardscontract.earned(cvxWalletAddress);

	const baseRewards = await stETH_ETH_pool.earned(cvxWalletAddress);
	const baseRewardsToken = await stETH_ETH_pool.rewardToken();

	const lidoFarmContract = new ethers.Contract('0xDC24316b9AE028F1497c275EB9192a3Ea0f67022', lido_curve_farm_abi, provider);
	const virtualPrice = await lidoFarmContract.get_virtual_price();

	// get CVX rewards
	const cvxRewardsContract = new ethers.Contract('0x4e3FBD56CD56c3e72c1403e103b45Db9da5B9D2B', cvxRewards_abi, provider);
	const reductionPerCliff = await cvxRewardsContract.reductionPerCliff();
	const totalCliffs = await cvxRewardsContract.totalCliffs();
	const maxSupply = await cvxRewardsContract.maxSupply();
	const supply = await cvxRewardsContract.totalSupply();
	const cvxRewards = calcCVX(baseRewards, supply, maxSupply, reductionPerCliff, totalCliffs);

	const aaveContract = new ethers.Contract('0x030bA81f1c18d280636F32af80b9AAd02Cf0854e', aaveAbi, provider);
	const aaveBalance = await aaveContract.balanceOf(aaveWalletAddress);

	// now check staked aave
	const aaveStakingContract = new ethers.Contract('0x4da27a545c0c5B758a6BA100e3a049001de870f5', aave_staking_abi, provider);
	const stakedBalAave = await aaveStakingContract.balanceOf(aaveWalletAddress);
	const aaveEarnt = await aaveStakingContract.getTotalRewardsBalance(aaveWalletAddress);

	const asudContract = new ethers.Contract('0xBcca60bB61934080951369a648Fb03DF4F96263C', ausdcAbi, provider);
	const asudBalanceLOF = await asudContract.balanceOf(ausdcWalletLOF);
	const asudBalanceHVMF = await asudContract.balanceOf(ausdcWalletHVMF);

	// get supplied USDC in compound
	const cusdcContract = '0xc3d688B66703497DAA19211EEdff47f25384cdc3';
	const compoundContract = new ethers.Contract(cusdcContract, compoundAbi, provider);
	const compoundRewardsContract = new ethers.Contract('0x1B0e765F6224C21223AeA2af16c1C46E38885a40', compoundRewardsAbi, provider);
	const cUSDCBalanceLOF = await compoundContract.balanceOf(cusdcWalletLOF);
	const cUSDCBalanceHVMF = await compoundContract.balanceOf(cusdcWalletHVMF);

	const [ , amtOwedHLOF ] = await compoundRewardsContract.getRewardOwed.staticCall(cusdcContract, cusdcWalletLOF);
	const [ , amtOwedHVMF ] = await compoundRewardsContract.getRewardOwed.staticCall(cusdcContract, cusdcWalletHVMF);

	// get staked MATIC
	const maticStakingContract = new ethers.Contract('0x9ee91F9f426fA633d227f7a9b000E28b9dfd8599', matc_staking_abi, provider);
	const stakedBalMatic = await maticStakingContract.balanceOf(maticWallet);
	const [amountInMatic, totalStMaticAmount, totalPooledMatic] = await maticStakingContract.convertStMaticToMatic(BigInt(1_000_000_000_000_000_000));

	const stakedEthContract = new ethers.Contract('0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84', stakedEth_abi, provider);
	let hlofStakedBalEth = await stakedEthContract.balanceOf(cvxWalletAddress);
	hlofStakedBalEth = hlofStakedBalEth + await stakedEthContract.balanceOf(hlofETHStakingWallet);

	// HVMF
	// get staked ETH
	const hvmfStakedBalEth = await stakedEthContract.balanceOf(hvmfETHStakingWallet);

	const blurBidContract = new ethers.Contract('0x0000000000A39bb272e79075ade125fd351887Ac', blurBid_abi, provider);

	// check balance of Blur wallets
	let blurDetails = 'Blur Wallets:\r\n';
	for (let i = 0; i < blurWallets.length; i++) {
		const wallet = blurWallets[i];
		const blurBalance = await blurBidContract.balanceOf(wallet);
		blurDetails += `${wallet}: ${ethers.formatUnits(blurBalance, DECIMALS)}\r\n`;
	}

	// get bendDAO
	const apeAddress = '0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D';
	const bendDAOContract = new ethers.Contract('0x9Da9571389BA2316ad98f695210aD5fB0363cDEd', bendDAO_abi, provider);
	const apeTotalPoolRewards = await bendDAOContract.getPoolStateUI(apeAddress);
	const totalApeRewards = await bendDAOContract.claimable([apeAddress], [apeIds]);

	// get sDAI / DAI from Spark
	const sparkContract = new ethers.Contract('0x83F20F44975D03b1b09e64809B757c47f942BEeA', spark_abi, provider);
	const sDaiBalance = await sparkContract.balanceOf(hlofSpark);
	const daiBalance = await sparkContract.convertToAssets(sDaiBalance);

	const outputStr = 'As of: ' + new Date().toUTCString() + '\r\nHLTV\r\n' +
		'Wallet Address: ' + cvxWalletAddress + '\r\n' +
		`Staked Balance: ${ethers.formatUnits(stakedBlanace, DECIMALS)}\r\n` +
		`Virtual Price: ${ethers.formatUnits(virtualPrice, DECIMALS)}\r\n` +
		`Earned: ${ethers.formatUnits(earned, DECIMALS)} ${getTokenName(rewardToken)}\r\n` +
		`Earned: ${ethers.formatUnits(baseRewards, DECIMALS)} ${getTokenName(baseRewardsToken)}\r\n` +
		`Earned: ${ethers.formatUnits(cvxRewards, DECIMALS)} CVX\r\n\r\n` +
		`USDC AAVE Supply wallet: ${ausdcWalletLOF}\r\n` +
		`aUSDC: ${ethers.formatUnits(asudBalanceLOF, 6)}\r\n` +
		`SPARK (DAI) Supply wallet: ${hlofSpark}\r\n` +
		`SPARK (sDAI): ${ethers.formatUnits(sDaiBalance, 18)}\r\n` +
		`SPARK (DAI): ${ethers.formatUnits(daiBalance, 18)}\r\n` +
		`USDC Compound Supply wallet: ${cusdcWalletLOF}\r\n` +
		`COMP: ${ethers.formatUnits(amtOwedHLOF, 18)}\r\n` +
		`cUSDC: ${ethers.formatUnits(cUSDCBalanceLOF, 6)}\r\n\r\n` +
		`Aave Wallet: ${aaveWalletAddress}\r\n` +
		`AWETH Balance: ${ethers.formatUnits(aaveBalance, DECIMALS)}\r\n` +
		`AWETH Earnt: ${ethers.formatUnits(aaveBalance, DECIMALS) - origAWETHBal}\r\n` +
		`Staked Aave: ${ethers.formatUnits(stakedBalAave, DECIMALS)}\r\n` +
		`Aave Earnt: ${ethers.formatUnits(aaveEarnt, DECIMALS)}\r\n\r\n` +
		`Staked Matic: ${ethers.formatUnits(stakedBalMatic, DECIMALS)}` + '\r\n' +
		`matic/stMatic ratio: ${ethers.formatUnits(amountInMatic, DECIMALS)}` + '\r\n' +
		`totalStMaticAmount: ${ethers.formatUnits(totalStMaticAmount, DECIMALS)}` + '\r\n' +
		`totalPooledMatic: ${ethers.formatUnits(totalPooledMatic, DECIMALS)}` + '\r\n' +
		`Staked ETH: ${ethers.formatUnits(hlofStakedBalEth, DECIMALS)}` + '\r\n' +
		`Staked ETH Earnt: ${ethers.formatUnits(hlofStakedBalEth, DECIMALS) - hlofOrigStakedEthBal}` + '\r\r\n\n' +
		`**HVMF**\r\nStaked ETH: ${ethers.formatUnits(hvmfStakedBalEth, DECIMALS)}` + '\r\n' +
		`Staked ETH Earnt: ${ethers.formatUnits(hvmfStakedBalEth, DECIMALS) - hvmfOrigStakedEthBal}` + '\r\n' +
		`USDC AAVE Supply wallet: ${ausdcWalletHVMF}\r\n` +
		`aUSDC: ${ethers.formatUnits(asudBalanceHVMF, 6)}\r\n` +
		`USDC Compound Supply wallet: ${cusdcWalletHVMF}\r\n` +
		`COMP: ${ethers.formatUnits(amtOwedHVMF, 18)}\r\n` +
		`cUSDC: ${ethers.formatUnits(cUSDCBalanceHVMF, 6)}\r\n\r\n` +
		`Apes staked (Global/Hivemind): ${Number(apeTotalPoolRewards[0])}/${apeIds.length}\r\n` +
		`Total Ape Rewards ($APE): ${ethers.formatUnits(totalApeRewards, DECIMALS)}\r\r\n\n` +
		blurDetails + '\r\r\n\n';

	await sendMessageToChannel('Daily Accural', outputStr, 'https://app.aave.com/');

	// print to pdf
	const startTime = new Date();
	const timestamp = startTime.toISOString().split('.')[0].replaceAll(':', '-');
	const filename = `./pdfs/Onchain_Accrual-${timestamp}.pdf`;

	const options = {
		orientation: 'p',
		unit: 'mm',
		format: 'a4',
		putOnlyUsedFonts:true,
		floatPrecision: 18,
	};

	const doc = new jsPDF(options);
	doc.text(outputStr, 10, 10);
	doc.save(filename);
}

function getTokenName(tokenAddress) {
	switch (tokenAddress) {
	case '0xD533a949740bb3306d119CC777fa900bA034cd52':
		return 'CRV';
	case '0x5A98FcBEA516Cf06857215779Fd812CA3beF1B32':
		return 'LDO';
	default:
		return 'UNKNOWN';
	}
}

function calcCVX(_amount, supply, maxSupply, reductionPerCliff, totalCliffs) {
	const cliff = supply / reductionPerCliff;
	if (cliff < totalCliffs) {
		// for reduction% take inverse of current cliff
		const reduction = totalCliffs - cliff;
		// reduce
		_amount = _amount * reduction / totalCliffs;

		// supply cap check
		const amtTillMax = maxSupply - supply;
		if (_amount > amtTillMax) {
			_amount = amtTillMax;
		}
	}
	return _amount;
}


/**
 * Send adaptive cards.
 */
// eslint-disable-next-line no-unused-vars
async function sendMessageToChannel(title, description, url) {
	new WebhookTarget(new URL(webhookUrl)).sendAdaptiveCard(
		AdaptiveCards.declare(template).render(
			{
				'title': title,
				'appName': 'Market Data Bot',
				'description': description,
				'notificationUrl' : url,
			}))
		.then(() => console.log('Send adaptive card successfully.\n'))
		.catch(e => console.log(`Failed to send adaptive card. ${e}`));
}

refreshPriceData();