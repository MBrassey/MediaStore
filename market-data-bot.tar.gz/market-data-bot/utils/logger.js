const { createLogger, format, transports } = require('winston');
require('winston-daily-rotate-file');

const infoLogger = createLogger({
	transports:
	new transports.DailyRotateFile({
		filename: 'server-%DATE%.log',
		dirname: 'logs',
		datePattern: 'YYYY-MM-DD',
		zippedArchive: false,
		level: 'debug',
		maxSize: '10m',
		maxFiles: '30d',
		utc: true,
		format:format.combine(
			format.timestamp({ format: 'MMM-DD-YYYY HH:mm:ss' }),
			format.align(),
			format.printf(info => `${info.level}: ${[info.timestamp]}: ${info.message}`),
		) }),
});

const nftLogger = createLogger({
	transports:
	new transports.DailyRotateFile({
		filename: 'nft-logs-%DATE%.log',
		dirname: 'logs',
		datePattern: 'YYYY-MM-DD',
		zippedArchive: false,
		level: 'info',
		maxSize: '10m',
		maxFiles: '30d',
		utc: true,
		format:format.combine(
			format.timestamp({ format: 'MMM-DD-YYYY HH:mm:ss' }),
			format.align(),
			format.printf(info => `${info.level}: ${[info.timestamp]}: ${info.message}`),
		) }),
});

module.exports = {
	infoLogger: infoLogger,
	nftLogger: nftLogger,
};