const ethers = require('ethers');
require('dotenv').config();
const fs = require('fs');
// eslint-disable-next-line no-unused-vars
const { inspect } = require('util');
const { AdaptiveCards } = require ('@microsoft/adaptivecards-tools');
const { WebhookTarget } = require('./webHookTarget.js');

const loadJSON = (pathname) => JSON.parse(fs.readFileSync(pathname));

const artBlockAbi = loadJSON('./abi/artBlocks_abi.json');
const template = loadJSON('./adaptiveCards/notification-default.json');
const webhookUrl = process.env.NFT_WEBHOOK;

const provider = new ethers.InfuraProvider('homestead', process.env.INFURA_API_KEY);

// ArtBlocks contract address
const contractAddress = '0xa7d8d9ef8d8ce8992df33d8b8cf4aebabd5bd270';


// Create a contract object
const contract = new ethers.Contract(contractAddress, artBlockAbi, provider);

const serialRanges = [
	{ 'fidenza':[78000000, 78000999] },
	{ 'ringer':[13000000, 13001000] },
];


const serialList = [];
const collectionMap = new Map();
for (const serialRange of serialRanges) {
	const startSerialNumber = serialRange[Object.keys(serialRange)[0]][0];
	const endSerialNumber = serialRange[Object.keys(serialRange)[0]][1];
	const collectionName = Object.keys(serialRange)[0];
	console.log(collectionName, startSerialNumber, endSerialNumber);
	for (let i = startSerialNumber; i <= endSerialNumber; i++) {
		collectionMap.set(i, collectionName);
		serialList.push(ethers.toBeHex(BigInt(i), 32));
	}
}


// Create a filter object
const artBlocksFilter = contract.filters.Transfer(null, null, serialList);

// eslint-disable-next-line no-unused-vars
async function getHistoricMoves() {
// get histoic moves for testing
	const events = await contract.queryFilter(artBlocksFilter, -10000);
	for (const event of events) {
		console.log(
			`Transfer of ${collectionMap.get(Number(event.args.tokenId))} NFT #${event.args.tokenId.toString()}: ${event.args.from} -> ${event.args.to}`,
		);
	}
}

/**
 * Send adaptive cards.
 */
// eslint-disable-next-line no-unused-vars
async function sendMessageToChannel(title, description, url) {
	new WebhookTarget(new URL(webhookUrl)).sendAdaptiveCard(
		AdaptiveCards.declare(template).render(
			{
				'title': title,
				'appName': 'Market Data Bot',
				'description': description,
				'notificationUrl' : url,
			}))
		.then(() => console.log('Send adaptive card successfully.\n'))
		.catch(e => console.log(`Failed to send adaptive card. ${e}`));
}

async function main() {
	getHistoricMoves();
	// Listen to transfer events with the filter
	contract.on(artBlocksFilter, (from, to, tokenId) => {
	// Log the event data to the console
		console.log(
			`Transfer of ${collectionMap.get(Number(tokenId))} NFT #${tokenId.toString()}: ${from} -> ${to}`,
		);
		sendMessageToChannel('Artblocks on the Move!', `Transfer of ${collectionMap.get(Number(tokenId))} NFT #${tokenId.toString()}: ${from} -> ${to}`, 'https://etherscan.io/token/0xa7d8d9ef8d8ce8992df33d8b8cf4aebabd5bd270');
	});
}

main();