const { AdaptiveCards } = require ('@microsoft/adaptivecards-tools');
const { WebhookTarget } = require('./webHookTarget.js');
const { infoLogger } = require('~utils/logger');
const { PriceAlert } = require('~models');
const fetch = require('cross-fetch');
const axios = require('axios');
const fs = require('fs');
const cron = require('node-cron');
require('dotenv').config();

const amberdataApiKey = process.env.AMBERDATA_API_KEY;
const AMBERDATA_BASE_URL = 'https://web3api.io/api/v2/market/';

const loadJSON = (pathname) => JSON.parse(fs.readFileSync(pathname));
const template = loadJSON('./adaptiveCards/notification-default.json');

const PUSH_URL = 'https://onesignal.com/api/v1/notifications';

const webhookUrl = process.env.WEBHOOK;
let timestamp;

const UP_PX = '⬆️ 🚀';
const DOWN_PX = '📉 🔻';

const dollarUS = Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'USD',
});

const maxRetries = 3;
const delim = '\t';

cron.schedule('*/5 * * * *', () => {
	timestamp = new Date();
	timestamp.setDate(timestamp.getDate() - 1);
	infoLogger.debug('Running alert check');
	checkAlerts();
});

async function checkAlerts() {
	// get alerts via sequielize
	const alerts = await PriceAlert.findAll();

	const instrumentList = [];
	const alertList = [];
	for (let i = 0; i < alerts.length; i++) {
		const alert = alerts[i];
		const pxAlert = new PxAlertObj(alert.asset, Number(alert.price), alert.alert, alert.expiry, alert.oneTime);
		infoLogger.debug(pxAlert.toString());
		alertList.push(pxAlert);
		if (!instrumentList.includes(pxAlert.asset)) instrumentList.push(pxAlert.asset);
	}

	const pxMap = new Map();
	// get prices via amberdata
	const promiseList = [];
	for (let i = 0; i < instrumentList.length; i++) {
		promiseList.push(getInstrumentPrice(instrumentList[i]));
	}
	await Promise.all(promiseList).then((cryptoObjectList) => {
		let outputStr = '';
		for (let c = 0; c < cryptoObjectList.length; c++) {
			const cryptoObj = cryptoObjectList[c];
			pxMap.set(cryptoObj.asset, cryptoObj);
			if (c == 0) outputStr = cryptoObj.getHeaders();

			outputStr += cryptoObj.toString();
		}
		infoLogger.info(outputStr);
	});

	// see if any alerts are triggered
	for (let i = 0; i < alertList.length; i++) {
		const alert = alertList[i];
		if (alert.alertTriggered(pxMap.get(alert.asset))) {
			// send alert
			let alertStr;
			if (alert.alertType == 'realtive') {
				if (pxMap.get(alert.asset).price > pxMap.get(alert.asset).oldPrice) {
					alertStr = UP_PX;
				}
				else {
					alertStr = DOWN_PX;
				}
			}
			else if (pxMap.get(alert.asset).price > alert.price) {
				alertStr = UP_PX;
			}
			else {
				alertStr = DOWN_PX;
			}
			alertStr += 'Alert triggered for ' + alert.asset + ' at ';

			alertStr += alert.alertType == 'relative' ? alert.price + '%' : dollarUS.format(alert.price);

			alertStr += ' current price is ' + dollarUS.format(pxMap.get(alert.asset).price);

			alertStr += alert.alertType == 'relative' ? ' historic price (24hr) ' + dollarUS.format(pxMap.get(alert.asset).oldPrice) : '';

			infoLogger.info(alertStr);
			infoLogger.debug('sending adaptive card...');
			await sendMessageToChannel('PRICE ALERT', alertStr, 'https://messari.io/dashboard');
			await sendPushNotification(alertStr);
			infoLogger.debug('sent');
			// if one touch, delete alert
			if (alert.oneTouch) {
				infoLogger.debug('deleting alert...');
				await alerts[i].destroy();
				infoLogger.debug('done');
			}
		}
		// clean up alerts if expires or one touch
		if (alert.isExpired()) {
			// delete alert
			infoLogger.debug('expired - deleting alert... ' + alert.toString());
			await alerts[i].destroy();
			infoLogger.debug('done');
		}
	}
}

const axiosPOST = async (u, d, c) => {
	let res;
	try {
		res = await axios.post(u, d, c);
	}
	catch (err) {
		console.log(err.code, err.message);
		console.log(err.response.data);
		return null;
	}
	return res.data;
};

async function sendPushNotification(message) {
	const config = {
		headers: {
			accept: 'application/json',
			Authorization: 'Basic ' + process.env.ONESIGNAL_REST_API,
			'content-type': 'application/json',
		},
	};

	const data = JSON.stringify({
		included_segments: ['Subscribed Users'],
		contents: { en: message },
		app_id: process.env.ONESIGNAL_APP_ID,
	});

	const res = await axiosPOST(PUSH_URL, data, config);

	if (res) infoLogger.log(res);
}

async function main() {
	timestamp = new Date();
	timestamp.setDate(timestamp.getDate() - 1);
	checkAlerts();
}

/**
 * Send adaptive cards.
 */
// eslint-disable-next-line no-unused-vars
async function sendMessageToChannel(title, description, url) {
	new WebhookTarget(new URL(webhookUrl)).sendAdaptiveCard(
		AdaptiveCards.declare(template).render(
			{
				'title': title,
				'appName': 'Market Data Bot',
				'description': description,
				'notificationUrl' : url,
			}))
		.then(() => console.log('Send adaptive card successfully.\n'))
		.catch(e => console.log(`Failed to send adaptive card. ${e}`));
}

/**
 * Obtain the key market data about the specified option
 * @param {string} instrument
 * @returns {PxObj}
 */
async function getInstrumentPrice(instrument) {
	const url = AMBERDATA_BASE_URL + `spot/prices/assets/${instrument}/latest/`;
	infoLogger.debug(url);
	const amberdataJSON = await fetchAmberdataJson(url);
	if (!amberdataJSON) {
		console.log('No data found for', instrument, 'check the name format and try again');
		return new PxObj(instrument, 'N/A', 'N/A');
	}
	const data = amberdataJSON.payload;
	return new PxObj(data.asset, data.price, data.volume, await getInstrumentHistoricalPrice(instrument));
}

async function getInstrumentHistoricalPrice(instrument) {
	const url = AMBERDATA_BASE_URL + `spot/prices/assets/${instrument}/historical/?startDate=${timestamp.getTime()}&endDate=${timestamp.getTime() + 60000}`;
	infoLogger.debug(url);
	const amberdataJSON = await fetchAmberdataJson(url);
	if (!amberdataJSON) {
		console.log('No historic price found for', instrument, 'check the name format and try again @ ', timestamp.toISOString());
	}
	const data = amberdataJSON.payload.data[0];
	if (!data) {
		console.log('No historic price found for', instrument, 'check the name format and try again @ ', timestamp.toISOString());
		return 'N/A';
	}
	return data.price;
}

/**
 * Helper function to retrieve JSON from REST API
 * @param {string} url
 * @param {number} depth
 * @param {number} retries
 * @returns {*}
 */
async function fetchAmberdataJson(url, depth = 0, retries = maxRetries) {
	if (depth >= retries) {
		infoLogger.info('Max retries reached', url, depth);
		return null;
	}
	depth++;
	try {

		const res = await fetchWithTimeout(url, {
			headers: {
				'accept': 'application/json',
				'x-api-key': amberdataApiKey,
			},
		});

		if (res.status != 200) {
			await sleep(1000 * depth);
			infoLogger.error(res.status, res.headers);
			return await fetchAmberdataJson(url, depth);
		}
		return res.json();

	}
	catch (err) {
		console.log('ERROR', err);
		await sleep(500 * depth);
		return await fetchAmberdataJson(url, depth);
	}
}

/**
 * basci sleep function
 * @param {numer} ms milliseconds to sleep
 * @returns {Promise}
 */
function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Wrapper to fetch to implement a timeout
 * @param {string} resource
 * @param {*} options
 * @returns {Response}
 */
async function fetchWithTimeout(resource, options = {}) {
	const { timeout = 50000 } = options;

	const controller = new AbortController();
	const id = setTimeout(() => controller.abort(), timeout);
	const response = await fetch(resource, {
		...options,
		signal: controller.signal,
	});
	clearTimeout(id);
	return response;
}

class PxObj {
	/**
	 * Encapuslate the option as an object
	 * @param {string} asset
	 * @param {string} price
	 * @param {string} volume
	 * @param {string} oldPrice
	 * @param {string=} objDelim delimeter overide else tab used
	 */
	constructor(asset, price, volume, oldPrice, objDelim = delim) {
		this.asset = asset;
		this.price = price;
		this.volume = volume;
		this.oldPrice = oldPrice;
		this.objDelim = objDelim;
	}

	toString() {
		return this.asset + this.objDelim +
			this.price + this.objDelim +
			this.volume + this.objDelim +
			this.oldPrice + this.objDelim + '\n';
	}

	getHeaders() {
		return 'Asset' + this.objDelim +
			'Price' + this.objDelim +
			'Volume' + this.objDelim +
			'24H Hist Px' + this.oldPrice + '\n';
	}
}

class PxAlertObj {
	/**
	 * Encapuslate the price alert as an object
	 * @param {string} asset
	 * @param {Number} price
	 * @param {string} alertType
	 * @param {Date} expires
	 * @param {boolean}	oneTouch
	 * @param {string=} objDelim delimeter overide else tab used
	 */
	constructor(asset, price, alertType, expires, oneTouch, objDelim = delim) {
		this.asset = asset;
		this.price = price;
		this.alertType = alertType.toLowerCase();
		this.expires = expires;
		this.oneTouch = oneTouch;
		this.objDelim = objDelim;
	}

	/*
	 * Check if the price alert has been triggered
	 * @param {PxObj} pxObj
	 * @returns {boolean}
	 * */
	alertTriggered(pxObj) {
		const px = parseFloat(pxObj.price);
		const histPx = parseFloat(pxObj.oldPrice);
		if (pxObj.asset != this.asset || isNaN(px)) {
			return false;
		}
		else if (this.alertType == 'above' && px > this.price) {
			return true;
		}
		else if (this.alertType == 'below' && px < this.price) {
			return true;
		}
		else if (this.alertType == 'relative' && !isNaN(histPx) && (Math.abs(px - histPx) / histPx) >= this.price / 100) {
			return true;
		}
		return false;
	}

	isExpired() {
		return this.expires < new Date();
	}

	toString() {
		return this.asset + this.objDelim +
			this.price + this.objDelim +
			this.alertType + this.objDelim +
			this.expires.toISOString() + this.objDelim +
			this.oneTouch + this.objDelim + '\n';
	}

	getHeaders() {
		return 'Asset' + this.objDelim +
			'Price' + this.objDelim +
			'AlertType' + this.objDelim +
			'Expires' + this.objDelim +
			'OneTouch' + this.objDelim + '\n';
	}
}

main();