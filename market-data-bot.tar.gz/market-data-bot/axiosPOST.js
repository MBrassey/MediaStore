const axios = require('axios');
require('dotenv').config();

const url = 'https://onesignal.com/api/v1/notifications';

const axiosPOST = async (u, d, c) => {
	let res;
	try {
		res = await axios.post(u, d, c);
	}
	catch (err) {
		console.log(err.code, err.message);
		console.log(err.response.data);
		return null;
	}
	return res.data;
};

async function main() {
	const config = {
		headers: {
			accept: 'application/json',
			Authorization: 'Basic ' + process.env.ONESIGNAL_REST_API,
			'content-type': 'application/json',
		},
	};

	// console.log(config);
	const data = JSON.stringify({
		included_segments: ['Subscribed Users'],
		contents: { en: '⬆️ 🚀 Alert 💸 or 📉 🔻' },
		app_id: process.env.ONESIGNAL_APP_ID,
	});
	// console.log(data);

	const res = await axiosPOST(url, data, config);

	if (res) console.log(res);
}

main();