'use strict';
const {
	Model,
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
	class PriceAlert extends Model {
	/**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
		static associate() {
			// define association here
		}
	}
	PriceAlert.init({
		asset: {
			type: DataTypes.STRING,
			allowNull: false,
			unique: false,
		},
		price: {
			type: DataTypes.DECIMAL(16, 8),
			allowNull: false,
		},
		alert: {
			type: DataTypes.ENUM,
			values: ['above', 'below', 'relative'],
			allowNull: false,
		},
		expiry: {
			type: DataTypes.DATE,
			allowNull: true,
		},
		oneTime: {
			type: DataTypes.BOOLEAN,
			allowNull: false,
			defaultValue: false,
		},
	}, {
		sequelize,
		modelName: 'PriceAlert',
		timestamps: true,
	});
	return PriceAlert;
};