const { AdaptiveCards } = require ('@microsoft/adaptivecards-tools');
const { WebhookTarget } = require('./webHookTarget.js');
const fs = require('fs');
const fetch = require('cross-fetch');
require('dotenv').config();

const loadJSON = (pathname) => JSON.parse(fs.readFileSync(pathname));

const webhookUrl = process.env.WEBHOOK;
const template = loadJSON('./adaptiveCards/notification-default.json');
const config = loadJSON('./config/msTeamsBot.json');
const amberdataApiKey = process.env.AMBERDATA_API_KEY;
const AMBERDATA_BASE_URL = 'https://web3api.io/api/v2/market/';
const MAX_RETRIES = 5;

let verbose = false;

// eslint-disable-next-line no-unused-vars
const lrgDollarUS = Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'USD',
	notation: 'compact',
	compactDisplay: 'short',
});

// eslint-disable-next-line no-unused-vars
const perc = new Intl.NumberFormat('default', {
	style: 'percent',
	minimumFractionDigits: 6,
	maximumFractionDigits: 6,
});

// eslint-disable-next-line no-unused-vars
const perc2dp = new Intl.NumberFormat('default', {
	style: 'percent',
	minimumFractionDigits: 2,
	maximumFractionDigits: 2,
});

/**
 * @param {string} exchange
 * @param {Map} assetVolMap
 * @param {Number} attempt
 * @returns {Map} assetVolMap
 */
async function getAssetLatest(exchange, assetVolMap, attempt = 0) {
	try {
		attempt++;
		const url = AMBERDATA_BASE_URL + `metrics/exchanges/${exchange}/assets/volumes/latest?quoteVolume=false&direction=desc`;
		if (verbose) console.log(url);
		const amberdataJSON = await fetchAmberdataJson(url);
		const amberdata = amberdataJSON.payload.data;
		for (const item of amberdata) {
			if (assetVolMap.has(item.asset)) {
				const oldValue = assetVolMap.get(item.asset);
				assetVolMap.set(item.asset, oldValue + Number(item.volumeUSD));
			}
		}

		return assetVolMap;
	}
	catch (err) {
		console.log(attempt, err);
		if (attempt <= MAX_RETRIES) {
			return getAssetLatest(exchange, assetVolMap);
		}
		else {
			console.log('Bad request on getting volumes - bugging out', attempt);
			return assetVolMap;
		}
	}
}

/**
 * @param {string} exchange
 * @param {Map} assetVolMap
 * @param {Number} attempt
 * @returns {Map} assetVolMap
 */
async function getAssetHistoric(exchange, asset, startTime, assetVolMap, attempt = 0) {
	let amberdataJSON;
	let url;
	try {
		attempt++;
		url = AMBERDATA_BASE_URL + `metrics/exchanges/${exchange}/assets/volumes/historical?asset=${asset}&quoteVolume=false&startDate=${startTime}`;
		if (verbose) console.log(url);
		amberdataJSON = await fetchAmberdataJson(url);
		if (verbose) console.log(amberdataJSON);
		if (!amberdataJSON) {
			return assetVolMap;
		}
		const amberdata = amberdataJSON.payload.data;
		for (const item of amberdata) {
			if (assetVolMap.has(item.asset)) {
				const oldValue = assetVolMap.get(item.asset);
				if (verbose) console.log(item.asset, oldValue, Number(item.volumeUSD));
				assetVolMap.set(item.asset, oldValue + Number(item.volumeUSD));
			}
		}

		return assetVolMap;
	}
	catch (err) {
		if (verbose) console.log(attempt, err, url);
		if (attempt <= MAX_RETRIES) {
			return getAssetHistoric(exchange, asset, startTime, assetVolMap, attempt);
		}
		else {
			console.log('Bad request on getting volumes - bugging out', attempt);
			return assetVolMap;
		}
	}
}

async function main() {
	verbose = getArgFlag('v');

	let assetVolumeMap = new Map();
	for (const token of config.volumes.tokens) {
		assetVolumeMap.set(token, 0);
	}
	for (const exchange of config.volumes.exchanges) {
		console.log(exchange);
		assetVolumeMap = await getAssetLatest(exchange, assetVolumeMap);
	}


	for (const [asset, volume] of assetVolumeMap.entries()) {
		console.log(asset, '\t', lrgDollarUS.format(volume));
	}
	const liveTimestamp = new Date();
	const historicTimeStamp = liveTimestamp.getTime() - (86400000 * (Number(config.volumes.lookback) + 1));
	console.log(historicTimeStamp);
	let historicVolumeMap = new Map();
	for (const token of config.volumes.tokens) {
		historicVolumeMap.set(token, 0);
	}

	for (const exchange of config.volumes.exchanges) {
		console.log(exchange);
		for (const token of config.volumes.tokens) {
			console.log(token);
			historicVolumeMap = await getAssetHistoric(exchange, token, historicTimeStamp, historicVolumeMap);
		}
	}

	let outputStr = 'asset\t24hr\t7d (Av.) Volumes\r\n';
	for (const [asset, volume] of historicVolumeMap.entries()) {
		outputStr += '- ' + asset + '\t' + lrgDollarUS.format(assetVolumeMap.get(asset)) + '\t/\t' + lrgDollarUS.format(volume / Number(config.volumes.lookback)) + '\r\n';
	}

	console.log(outputStr);
	// await sendMessageToChannel('Trading Volumes', outputStr, 'https://www.coinglass.com/');

}


/**
 * Helper method to check an argument flag is present
 * @param {string} arg
 * @returns {boolean}
 */
function getArgFlag(arg) {
	const customIndex = process.argv.indexOf(`-${arg}`);

	if (customIndex > -1) {
		return true;
	}

	return false;
}

/**
 * Send adaptive cards.
 */
// eslint-disable-next-line no-unused-vars
async function sendMessageToChannel(title, description, url) {
	new WebhookTarget(new URL(webhookUrl)).sendAdaptiveCard(
		AdaptiveCards.declare(template).render(
			{
				'title': title,
				'appName': 'Market Data Bot',
				'description': description,
				'notificationUrl' : url,
			}))
		.then(() => console.log('Send adaptive card successfully.'))
		.catch(e => console.log(`Failed to send adaptive card. ${e}`));
}

/**
 * Helper function to retrieve JSON from REST API
 * @param {string} url
 * @param {number} depth
 * @param {number} retries
 * @returns {*}
 */
async function fetchAmberdataJson(url, depth = 0, retries = MAX_RETRIES) {
	if (depth >= retries) return null;
	depth++;
	try {

		const res = await fetchWithTimeout(url, {
			headers: {
				'accept': 'application/json',
				'x-api-key': amberdataApiKey,
			},
		});

		if (res.status != 200) {
			const respJson = await res.json();
			if (verbose) console.log('msg:', respJson);
			if (respJson.message == 'No assets found for the specified exchange.') {
				return null;
			}
			else {
				await sleep(1000 * depth);
				console.log(res.status, res.headers);
				return await fetchJson(url, depth);
			}
		}
		return res.json();

	}
	catch (err) {
		if (verbose) console.log(err);
		await sleep(500 * depth);
		return await fetchJson(url, depth);
	}
}

/**
 * Helper function to retrieve JSON from REST API
 * @param {string} url
 * @param {number} depth
 * @param {number} retries
 * @returns {*}
 */
async function fetchJson(url, depth = 0, retries = MAX_RETRIES) {
	if (depth >= retries) return null;
	depth++;
	try {
		const res = await fetchWithTimeout(url);
		if (res.status != 200) {
			await sleep(500 * depth);
			return await fetchJson(url, depth);
		}
		return res.json();

	}
	catch (err) {
		await sleep(500 * depth);
		return await fetchJson(url, depth);
	}
}


/**
 * basci sleep function
 * @param {numer} ms milliseconds to sleep
 * @returns {Promise}
 */
function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Wrapper to fetch to implement a timeout
 * @param {string} resource
 * @param {*} options
 * @returns {Response}
 */
async function fetchWithTimeout(resource, options = {}) {
	const { timeout = 30000 } = options;

	const controller = new AbortController();
	const id = setTimeout(() => controller.abort(), timeout);
	const response = await fetch(resource, {
		...options,
		signal: controller.signal,
	});
	clearTimeout(id);
	return response;
}

main()
	.then()
	.catch(error => {
		console.error(error);
		process.exit(1);
	});