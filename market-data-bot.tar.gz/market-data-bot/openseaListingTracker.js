require('dotenv').config();
const { EventType, OpenSeaStreamClient } = require('@opensea/stream-js');
const { WebSocket } = require('ws');
const { inspect } = require('util');
const fs = require('fs');
const { AdaptiveCards } = require ('@microsoft/adaptivecards-tools');
const { WebhookTarget } = require('./webHookTarget.js');
const { nftLogger } = require('~utils/logger');
const cron = require('node-cron');
const { ethers } = require('ethers');
const axios = require('axios');

const loadJSON = (pathname) => JSON.parse(fs.readFileSync(pathname));
const basicTemplate = loadJSON('./adaptiveCards/notification-default.json');
const listingTemplate = loadJSON('./adaptiveCards/nft-listed-notification.json');
const transferTemplate = loadJSON('./adaptiveCards/nft-transfer-notification.json');
const soldTemplate = loadJSON('./adaptiveCards/nft-sold-notification.json');
const webhookUrl = process.env.NFT_WEBHOOK;

const collectionPrintMap = new Map();

const config = loadJSON('./config/nftAddressBook.json');

const addressMap = new Map();

class AddressMessages {
	constructor(message, to, from) {
		this.message = message;
		this.to = to;
		this.from = from;
	}

	getMessage() {
		return this.message;
	}

	getToMessage() {
		return this.to + ' -> ' + this.message;
	}

	getFromMessage() {
		return this.from + ' -> ' + this.message;
	}
}

for (const c of config) {
	const address = c.address.toLowerCase();
	const messages = new AddressMessages(address, c.to, c.from);
	addressMap.set(address, messages);
	console.log(`Address: ${address} -> ${c.message}`);
}

const LB = '\n\r';
const excludeBelow = process.env.SUPPRESS_BACK_BID || 5;
const supressShorterThan = process.env.SUPPRESS_SHORTER_THAN || 0.04;

const dateFormatOptions = { year: 'numeric', month: 'short', day: 'numeric', timeZoneName: 'short', hour: 'numeric', minute: 'numeric', second: 'numeric' };

function formatDateTime(date) {
	return date.toLocaleDateString('en-UK', dateFormatOptions);
}

cron.schedule('0 */15 * * * *', () => {
	console.log('Purging old listings...');
	purgeOldListings();
}, {
	timezone: 'UTC',
	utcOffset: 0,
});

cron.schedule('0 */20 * * * *', () => {
	updatePrintAvailability();
}, {
	timezone: 'UTC',
	utcOffset: 0,
});

// TODO: Sold message do not identify whether it was a lift or a bid was hit. We could query etherscan to see which way the NFT moved ot assess

// string formatter 2 decimal places
const twoDP = (num) => Number(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fourDP = (num) => Number(num).toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 });

const listingMap = new Map();

const eventList = [EventType.ITEM_LISTED, EventType.ITEM_TRANSFERRED, EventType.ITEM_SOLD, EventType.COLLECTION_OFFER, EventType.TRAIT_OFFER];

const collectionSlugList = process.env.COLLECTION_LIST.split(',');
const squelchList = process.env.SQUELCH_LIST.split(',') ?? [];

const client = new OpenSeaStreamClient({
	token: process.env.OPENSEA_API_KEY,
	connectOptions: {
		transport: WebSocket,
	},
	onError: (error) => {
		console.error(inspect(error, false, 1, true));
	},
});

for (const collectionSlug of collectionSlugList) {
	console.log(`Listening for events on ${collectionSlug}`);
	client.onEvents(
		collectionSlug,
		eventList,
		(event) => {
			parseEvent(event);
		},
	);
}

for (const squelch of squelchList) {
	console.log(`Squelching listing events on ${squelch}`);
}

function purgeOldListings() {
	let counter = 0;
	const now = new Date().getTime();
	for (const [key, value] of listingMap.entries()) {
		// purge listing entries > 1 hour old
		if (now - value > 1000 * 60 * 60) {
			listingMap.delete(key);
			counter++;
		}
	}
	console.log(`Purged ${counter} old listings`);
	nftLogger.info(`Purged ${counter} old listings`);
}

async function parseEvent(event) {
	// console.log(inspect(event));
	const slug = event.payload.collection.slug;
	let msg = `Collection: ${slug} ${LB}`;
	let publish = false;
	let postToWebhook = false;
	let renderedCard;
	let name;
	let listingId;
	let tokenId;
	switch (event.event_type) {
	case EventType.ITEM_LISTED:
		// console.log(inspect(event, false, 5, true));
		name = event.payload.item.metadata.name ? event.payload.item.metadata.name : `#${event.payload.item.nft_id.match(/\/([0-9]+)$/)[1]}`;
		msg += `Item listed -> ${name}${LB}`;

		// check if the item has a print
		tokenId = Number(event.payload.item.nft_id.match(/\/([0-9]+)$/)[1]);
		if (collectionPrintMap.has(slug)) {
			const printMap = collectionPrintMap.get(slug);
			if (printMap.has(tokenId)) {
				msg += `Print is ${printMap.get(tokenId)}${LB}`;
				console.log(`Looking up: ${printMap.get(tokenId)} / ${tokenId} / ${slug} / ${name}}`);
				console.dir(printMap, { depth: 5, color: true });
			}
			else {
				msg += `Error: Print Info is not available for ${event.payload.item.nft_id.match(/\/([0-9]+)$/)[1]}${LB}`;
			}
		}


		msg += `Offer: ${twoDP(ethers.formatUnits(BigInt(event.payload.base_price), event.payload.payment_token.decimals))} ${event.payload.payment_token.symbol} ($${twoDP(event.payload.payment_token.usd_price * ethers.formatUnits(BigInt(event.payload.base_price), event.payload.payment_token.decimals))})${LB}`;
		// + `Image: ${event.payload.item.metadata.image_url} ${LB}`
		msg += addressMap.has(event.payload.maker.address.toLowerCase()) ?
			`Seller: ${addressMap.get(event.payload.maker.address.toLowerCase()).getMessage()}${LB}` :
			`Seller: ${event.payload.maker.address} ${LB}`;
		msg += `Valid until: ${twoDP((new Date(event.payload.expiration_date) - new Date()) / (1000 * 60 * 60 * 24))} day(s) [ ${formatDateTime(new Date(event.payload.expiration_date))} ]${LB}`;

		// hash the name, offer and rounded time to expiry to create a unique id for the listing
		listingId = ethers.keccak256(ethers.toUtf8Bytes(`${name}${event.payload.base_price}${twoDP((new Date(event.payload.expiration_date) - new Date()) / (1000 * 60 * 60 * 24))}`));
		if (!listingMap.has(listingId)) {
			listingMap.set(listingId, new Date().getTime());
			publish = true;
			if (!squelchList.includes(event.payload.collection.slug)) {
				postToWebhook = true;
				renderedCard = AdaptiveCards.declare(listingTemplate).render(
					{
						'title': `New listing: ${name}`,
						'appName': 'NFT Bot',
						'description': msg,
						'permalink' : event.payload.item.permalink,
						'image': event.payload.item.metadata.image_url,
						'seller': `https://platform.arkhamintelligence.com/explorer/address/${event.payload.maker.address}`,
					});
			}
		}
		else {
			console.log(`Duplicate listing event: ${listingId} / ${name} / ${name}${event.payload.base_price}${twoDP((new Date(event.payload.expiration_date) - new Date()) / (1000 * 60 * 60 * 24))}`);
		}
		break;
	case EventType.ITEM_TRANSFERRED:
		// console.log(inspect(event, false, 3, true));
		name = event.payload.item.metadata.name ? event.payload.item.metadata.name : `#${event.payload.item.nft_id.match(/\/([0-9]+)$/)[1]}`;

		msg += `Item transferred -> ${name}${LB}`;

		msg += addressMap.has(event.payload.from_account.address) ?
			`From: ${addressMap.get(event.payload.from_account.address).getFromMessage()}${LB}` :
			`From: ${event.payload.from_account.address}${LB}`;

		msg += addressMap.has(event.payload.to_account.address) ?
			`To: ${addressMap.get(event.payload.to_account.address).getToMessage()}${LB}` :
			`To: ${event.payload.to_account.address}${LB}`;

		// + `Link: ${event.payload.item.permalink} ${LB}`
		// + `Image: ${event.payload.item.metadata.image_url} ${LB}`
		// + `Tx Hash: ${event.payload.transaction.hash} ${LB}`
		msg += `Timestamp: ${formatDateTime(new Date(event.payload.transaction.timestamp))} ${LB}`;

		listingId = 'TRANSFER' + event.payload.transaction.hash + name;
		if (!listingMap.has(listingId)) {
			listingMap.set(listingId, new Date().getTime());
			publish = true;
			postToWebhook = true;
			renderedCard = AdaptiveCards.declare(transferTemplate).render(
				{
					'title': `Transfer: ${name}`,
					'appName': 'NFT Bot',
					'description': msg,
					'permalink' : event.payload.item.permalink,
					'image': event.payload.item.metadata.image_url,
					'from': `https://platform.arkhamintelligence.com/explorer/address/${event.payload.from_account.address}`,
					'to': `https://platform.arkhamintelligence.com/explorer/address/${event.payload.to_account.address}`,
					'etherscan': `https://etherscan.io/tx/${event.payload.transaction.hash}`,
				});
		}
		else {
			console.log(`Duplicate transfer event: ${listingId} / ${name}`);
		}
		break;
	case EventType.ITEM_SOLD:
		// console.log(inspect(event, false, 3, true));
		name = event.payload.item.metadata.name ? event.payload.item.metadata.name : `#${event.payload.item.nft_id.match(/\/([0-9]+)$/)[1]}`;
		msg += `Item 💥SOLD💥 -> ${name}${LB}`
			+ `Price: ${twoDP(ethers.formatUnits(BigInt(event.payload.sale_price), event.payload.payment_token.decimals))} ${event.payload.payment_token.symbol} ($${twoDP(event.payload.payment_token.usd_price * ethers.formatUnits(BigInt(event.payload.sale_price), event.payload.payment_token.decimals))})${LB}`
			+ `Image: ${event.payload.item.metadata.image_url} ${LB}`;

		msg += addressMap.has(event.payload.taker.address.toLowerCase()) ?
			`Taker: ${addressMap.get(event.payload.taker.address.toLowerCase()).getMessage()}${LB}` :
			`Taker: ${event.payload.taker.address} ${LB}`;

		msg += addressMap.has(event.payload.maker.address.toLowerCase()) ?
			`Maker: ${addressMap.get(event.payload.maker.address.toLowerCase()).getMessage()}${LB}` :
			`Maker: ${event.payload.maker.address} ${LB}`;
		msg += `Execution Time: ${formatDateTime(new Date(event.payload.transaction.timestamp))} ${LB}`;

		listingId = 'SOLD' + event.payload.transaction.hash;
		if (!listingMap.has(listingId)) {
			listingMap.set(listingId, new Date().getTime());
			publish = true;
			postToWebhook = true;
			renderedCard = AdaptiveCards.declare(soldTemplate).render(
				{
					'title': `SALE: ${name}`,
					'appName': 'NFT Bot',
					'description': msg,
					'permalink' : event.payload.item.permalink,
					'image': event.payload.item.metadata.image_url,
					'maker': `https://platform.arkhamintelligence.com/explorer/address/${event.payload.maker.address}`,
					'taker': `https://platform.arkhamintelligence.com/explorer/address/${event.payload.taker.address}`,
					'etherscan': `https://etherscan.io/tx/${event.payload.transaction.hash}`,
				});
		}
		else {
			console.log(`Duplicate sale event: ${listingId} / ${name}`);
		}
		break;
	case EventType.COLLECTION_OFFER:
		// console.log(inspect(event, false, 5, true));
		if (Number(twoDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals))) >= excludeBelow
		&& twoDP((new Date(Number(event.payload.protocol_data.parameters.endTime) * 1000) - new Date()) / (1000 * 60 * 60 * 24)) >= supressShorterThan) {
			msg += `Collection offer ${LB}`
			+ `Qty: ${event.payload.quantity} @ ${fourDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals))} ${event.payload.payment_token.symbol} ($${twoDP(fourDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals)) * event.payload.payment_token.usd_price)})${LB}`;
			msg += addressMap.has(event.payload.maker.address.toLowerCase()) ?
				`From: ${addressMap.get(event.payload.maker.address.toLowerCase()).getMessage()}${LB}` :
				`From: ${event.payload.maker.address} ${LB}`;
			msg	+= `Valid until: ${twoDP((new Date(Number(event.payload.protocol_data.parameters.endTime) * 1000) - new Date()) / (1000 * 60 * 60 * 24))} day(s) [ ${formatDateTime(new Date(Number(event.payload.protocol_data.parameters.endTime) * 1000))} ] ${LB}`;
			publish = true;
			listingId = 'COLLECTIONOFFER' +
				ethers.keccak256(ethers.toUtf8Bytes(`${name}${twoDP((new Date(Number(event.payload.protocol_data.parameters.endTime) * 1000) - new Date()) / (1000 * 60 * 60 * 24))}${event.payload.quantity}${ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals)}${event.payload.payment_token.symbol} ($${twoDP(fourDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals)))}`));
			if (!listingMap.has(listingId)) {
				listingMap.set(listingId, new Date().getTime());
				postToWebhook = true;
				renderedCard = AdaptiveCards.declare(basicTemplate).render(
					{
						'title': `Collection Offer - ${event.payload.collection.slug}`,
						'appName': 'NFT Bot',
						'description': msg,
						'notificationUrl' : `https://opensea.io/collection/${event.payload.collection.slug}`,
					});
			}
			else {
				console.log(`Duplicate collection offer: ${event.payload.collection.slug} -> ${listingId} / ${event.payload.quantity} @ ${fourDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals))} ${event.payload.payment_token.symbol} ($${twoDP(fourDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals)) * event.payload.payment_token.usd_price)})`);
			}
		}
		break;
	case EventType.TRAIT_OFFER:
		// console.log(inspect(event, false, 5, true));
		if (Number(twoDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals))) >= excludeBelow
			&& twoDP((new Date(Number(event.payload.protocol_data.parameters.endTime) * 1000) - new Date()) / (1000 * 60 * 60 * 24)) >= supressShorterThan) {
			msg += `Trait offer: ${event.payload.trait_criteria.trait_type} -> ${event.payload.trait_criteria.trait_name} ${LB}`
			+ `Qty: ${event.payload.quantity} @ ${fourDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals))} ${event.payload.payment_token.symbol} ($${twoDP(fourDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals)) * event.payload.payment_token.usd_price)})${LB}`;
			msg += addressMap.has(event.payload.maker.address.toLowerCase()) ?
				`From: ${addressMap.get(event.payload.maker.address.toLowerCase()).getMessage()}${LB}` :
				`From: ${event.payload.maker.address} ${LB}`;
			msg += `Valid until: ${twoDP((new Date(Number(event.payload.protocol_data.parameters.endTime) * 1000) - new Date()) / (1000 * 60 * 60 * 24))} day(s) [ ${formatDateTime(new Date(Number(event.payload.protocol_data.parameters.endTime) * 1000))} ] ${LB}`;
			publish = true;
			listingId = event.payload.trait_criteria.trait_type + event.payload.trait_criteria.trait_name +
				ethers.keccak256(ethers.toUtf8Bytes(`${name}${twoDP((new Date(Number(event.payload.protocol_data.parameters.endTime) * 1000) - new Date()) / (1000 * 60 * 60 * 24))}${event.payload.quantity}${ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals)}${event.payload.payment_token.symbol} ($${twoDP(fourDP(ethers.formatUnits(BigInt(event.payload.protocol_data.parameters.offer[0].startAmount), event.payload.payment_token.decimals)))}`));
			if (!listingMap.has(listingId)) {
				listingMap.set(listingId, new Date().getTime());
				postToWebhook = true;
				renderedCard = AdaptiveCards.declare(basicTemplate).render(
					{
						'title': `Trait Offer - ${event.payload.collection.slug}`,
						'appName': 'NFT Bot',
						'description': msg,
						'notificationUrl' : `https://opensea.io/collection/${event.payload.collection.slug}`,
					});
			}
			else {
				console.log(`Duplicate trait offer: ${event.payload.collection.slug} -> ${listingId} /  ${event.payload.trait_criteria.trait_type} -> ${event.payload.trait_criteria.trait_name}`);
			}
		}
		break;
	default:
		msg = `Unknown event type: ${inspect(event, false, 2, true)}`;
		publish = true;
	}

	if (publish) nftLogger.info(msg);
	if (postToWebhook) {
		sendMessageToChannel(renderedCard);
	}

}

async function updatePrintAvailability() {
	console.log('Updating print availability...');
	// fidenza
	try {
		const oldFidenzaMap = collectionPrintMap.get('fidenza-by-tyler-hobbs') ?? new Map();
		const fidenzaPrints = await getFidenzaPrints();
		// check if the entries have shrunk
		if (oldFidenzaMap.size != 0 && oldFidenzaMap.size > fidenzaPrints.size) {
			nftLogger.info(`Fidenza print availability has shrunk from ${oldFidenzaMap.size} to ${fidenzaPrints.size}`);
			// compare items in the maps to work out what happened
			for (const [key] of oldFidenzaMap.entries()) {
				if (!fidenzaPrints.has(key)) {
					nftLogger.info(`Fidenza print ${key} is no longer available`);
				}
			}
		}
		else if (oldFidenzaMap.size != 0 && oldFidenzaMap.size < fidenzaPrints.size) {
			nftLogger.info(`Fidenza print availability has grown from ${oldFidenzaMap.size} to ${fidenzaPrints.size}`);
			// compare items in the maps to work out what happened
			for (const [key] of fidenzaPrints.entries()) {
				if (!oldFidenzaMap.has(key)) {
					nftLogger.info(`Fidenza print ${key} is now available`);
				}
			}
		}
		collectionPrintMap.set('fidenza-by-tyler-hobbs', fidenzaPrints);
	}
	catch (e) {
		console.log('Error fetching fidenza prints', e);
	}

	// now check ringers
	try {
		const oldRingersMap = collectionPrintMap.get('ringers-by-dmitri-cherniak') ?? new Map();
		const ringersPrints = await getRingersPrints();
		// check if the entries have shrunk
		if (oldRingersMap.size != 0 && oldRingersMap.size > ringersPrints.size) {
			nftLogger.info(`Ringers print availability has shrunk from ${oldRingersMap.size} to ${ringersPrints.size}`);
			// compare items in the maps to work out what happened
			for (const [key] of oldRingersMap.entries()) {
				if (!ringersPrints.has(key)) {
					nftLogger.info(`Ringers print ${key} is no longer available`);
				}
			}
		}
		else if (oldRingersMap.size != 0 && oldRingersMap.size < ringersPrints.size) {
			nftLogger.info(`Ringers print availability has grown from ${oldRingersMap.size} to ${ringersPrints.size}`);
			// compare items in the maps to work out what happened
			for (const [key] of ringersPrints.entries()) {
				if (!oldRingersMap.has(key)) {
					nftLogger.info(`Ringers print ${key} is now available`);
				}
			}
		}
		collectionPrintMap.set('ringers-by-dmitri-cherniak', ringersPrints);
	}
	catch (e) {
		console.log('error fetching ringers prints', e);
	}
}

async function getFidenzaPrints() {
	const url = 'https://anticlassic.herokuapp.com/api/v1/notion/fidenza/requests';
	const response = await axios.get(url);

	// loop through from 0 to 998, and check if the token is in the response.data pending or completed else available
	// create a map of token to status
	const tokenStatus = new Map();
	const pending = response.data.pending;
	const completed = response.data.completed;
	for (let i = 0; i < 998; i++) {
		const token = i + 78000000;
		if (pending.includes(i)) {
			tokenStatus.set(token, '*Pending*');
		}
		else if (completed.includes(i)) {
			tokenStatus.set(token, '**GONE**');
		}
		else {
			tokenStatus.set(token, 'Available');
		}
	}
	// console.log('Fidenza print availability:');
	// console.dir(tokenStatus, { depth: 5, color: true });

	return tokenStatus;
}

async function getRingersPrints() {
	const url = 'https://docs.google.com/spreadsheets/u/1/d/1vVCFwGdrsyZ3fhV_l-0nPm8Zb9ywrXKtFYLuYOUiOTw/htmlview';
	const response = await axios.get(url);
	// console.log(response.data);

	const regex = /<td class="s1" dir="ltr">(\d+)<\/td>/g;
	const regexGroup = /<td class="s1" dir="ltr">(\d+)<\/td>/;

	const matches = response.data.match(regex);

	let lastToken = -1;
	const tokenStatus = new Map();
	// fill items 0 to 999 as available
	for (let i = 13000000; i < 13000999; i++) {
		tokenStatus.set(i, 'Available');
	}
	// now update for those that are not available
	for (const match of matches) {
		const token = Number(match.match(regexGroup)[1]) + 13000000;
		if (token > lastToken) {
			tokenStatus.set(token, '**GONE**');
			lastToken = token;
		}
	}
	// console.log('Ringers print availability:');
	// console.dir(tokenStatus, { depth: 5, color: true });

	return tokenStatus;
}

/**
 * Send adaptive cards.
 */
// eslint-disable-next-line no-unused-vars
async function sendMessageToChannel(renderedCard) {
	console.log('Sending message to channel..');
	// eslint-disable-next-line no-unreachable
	new WebhookTarget(new URL(webhookUrl)).sendAdaptiveCard(renderedCard)
		.then(() => console.log('Send adaptive card successfully.\n'))
		.catch(e => console.log(`Failed to send adaptive card. ${e}`));

}

updatePrintAvailability();