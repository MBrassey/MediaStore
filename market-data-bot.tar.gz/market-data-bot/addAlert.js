const { infoLogger } = require('~utils/logger');
const { PriceAlert } = require('~models');

async function main() {
	// read in arguments from the command line
	const args = process.argv.slice(2);
	if (args.length < 4 || args.length > 5) {
		console.log('usage: node addAlert.js <asset> <price> <alertType> <expiry> <oneTime>');
		console.log('\t\t\talertType must be "above", "below" or "relative"');
		console.log('\t\t\t\t if "relative" then price is a percentage');
		console.log('\t\t\texpiry format "YYYY-MM-DD"');
		console.log('\t\t\toneTime must be 1 or 0 (default false if omitted)');
		infoLogger.error('Incorrect number of arguments', args);
		process.exit(1);
	}

	const asset = args[0].toLowerCase();
	const price = Number(args[1]);
	const alertType = args[2];
	const expiry = new Date(args[3]);
	const oneTime = args[4] ? Boolean(Number(args[4])) : false;

	if (alertType.toLowerCase() == 'above' || alertType.toLowerCase() == 'below' || alertType.toLowerCase() == 'relative') {
		const alert = await PriceAlert.create({
			asset,
			price,
			alert: alertType.toLowerCase(),
			expiry,
			oneTime,
		});
		infoLogger.info(`Alert created for ${asset} at ${price} ${alertType} ${expiry}`);
		await alert.save();
	}
	else {
		console.log('Alert type must be "above", "below" or "relative"');
		infoLogger.error('Incorrect alert type', args);
		process.exit(1);
	}

}

main().then(() => {
	console.log('Complete');
	process.exit(0);
}).catch(error => {
	console.error(error);
	infoLogger.error(error);
	process.exit(1);
});