const { AdaptiveCards } = require ('@microsoft/adaptivecards-tools');
const { WebhookTarget } = require('./webHookTarget.js');
const fs = require('fs');
const fetch = require('cross-fetch');
const cron = require('node-cron');
const axios = require('axios');
require('dotenv').config();

const GBTC_DISCOUNT_URL = 'https://ycharts.com/companies/GBTC';
const ETHE_DISCOUNT_URL = 'https://ycharts.com/companies/ETHE';
const HASHRATE_URL = 'https://api.minerstat.com/v2/coins?list=BTC';

const loadJSON = (pathname) => JSON.parse(fs.readFileSync(pathname));

const webhookUrl = process.env.WEBHOOK;
const template = loadJSON('./adaptiveCards/notification-default.json');
const config = loadJSON('./config/msTeamsBot.json');
const amberdataApiKey = process.env.AMBERDATA_API_KEY;
const AMBERDATA_BASE_URL = 'https://web3api.io/api/v2/market/';
const AMBERDATA_NEW_BASE_URL = 'https://web3api.io/api/v2/';
const MAX_RETRIES = 10;
const LIQ_THRESHOLD = process.env.LIQ_THRESHOLD;

let lastRunTime = new Date().getTime();
let verbose = false;
const delim = '\t';
const dollarUS = Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'USD',
});

const lrgDollarUS = Intl.NumberFormat('en-US', {
	style: 'currency',
	currency: 'USD',
	notation: 'compact',
	compactDisplay: 'short',
});

const perc = new Intl.NumberFormat('default', {
	style: 'percent',
	minimumFractionDigits: 6,
	maximumFractionDigits: 6,
});

const perc2dp = new Intl.NumberFormat('default', {
	style: 'percent',
	minimumFractionDigits: 2,
	maximumFractionDigits: 2,
});

const exaHash = new Intl.NumberFormat('default', {
	notation: 'compact',
	compactDisplay: 'short',
});

cron.schedule('*/15 * * * *', () => {
	lastRunTime = new Date().getTime();
	processLiquidationData();
});

cron.schedule('30 6 * * *', () => {
	lastRunTime = new Date().getTime();
	processDailyLiquidationData();
});

cron.schedule('30 59 23,7,15 * * *', () => {
	processFundingData();
});

cron.schedule('30 15 3,9,15,21 * * *', () => {
	processLendingData();
});

cron.schedule('30 01 12 * * 1-5', () => {
	fetchGBTCDiscount();
	fetchETHEDiscount();
});

cron.schedule('45 30 11,23 * * *', () => {
	fetchHashRateDiscount();
});

cron.schedule('15 10 5,17 * * *', () => {
	fetchAssetVolumeData();
});

const axiosConfig = {
	headers: {
		'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
		'accept-language': 'en-US,en;q=0.5',
		'accept-encoding': 'gzip, deflate, br',
	},
};

async function processLiquidationData() {
	let consolidatedOutput = '';
	for (const instrument of config.liquidations) {
		// get the liquidation in last 15 mins
		const output = await getLiquidations(instrument, lastRunTime - 60000 * 15, lastRunTime, LIQ_THRESHOLD);
		if (output) consolidatedOutput += output;
	}
	if (consolidatedOutput) {
		console.log(consolidatedOutput);
		sendMessageToChannel('LIQUIDATION ALERT', consolidatedOutput, 'https://www.coinglass.com/LiquidationData');
	}
	console.log(new Date().toISOString(), 'LIQ DATA COMPLETE');
}

async function processDailyLiquidationData() {
	let consolidatedOutput = '';
	for (const instrument of config.liquidations) {
		// get the liquidation in last 24 Hours
		const output = await getLiquidations(instrument, lastRunTime - 3600000 * 24, lastRunTime);
		if (output) consolidatedOutput += output;
	}
	console.log(consolidatedOutput);
	sendMessageToChannel('Daily Liquidation Recap', consolidatedOutput, 'https://www.coinglass.com/LiquidationData');
	console.log(new Date().toISOString(), 'LIQ *DAILY* COMPLETE');
}

async function processFundingData() {
	let output = '';
	for (const instrument of config.funding) {
		output += await getFundingRates(instrument);
	}
	console.log(output);
	sendMessageToChannel('Funding Refresh', output, 'https://www.coinglass.com/');
	console.log(new Date().toISOString(), 'FUNDING DATA COMPLETE');
}

async function processLendingData(send = true) {
	let output = 'Token@venue supply/borrow (v)/borrow(s)\r\n';
	for (const protocol of config.lending) {
		for (const token of protocol.tokens) {
			output = output + await getLendingData(protocol.protocol, token);
		}
	}
	console.log(output);
	if (send) {
		sendMessageToChannel('Lending Refresh', output, 'https://app.aave.com/');
	}
	console.log(new Date().toISOString(), 'LENDING DATA COMPLETE');
}

async function main() {
	verbose = getArgFlag('v');
	console.log('Running Liquidation data for', config.liquidations);
	for (const instrument of config.liquidations) {
		console.log(await getLiquidations(instrument, lastRunTime - 3600000 * 24, lastRunTime));
	}

	console.log('Running funding data for', config.funding);

	for (const instrument of config.funding) {
		console.log(await getFundingRates(instrument));
	}

	console.log('Running lending rates for', config.lending);
	processLendingData(false);

	fetchGBTCDiscount(false);

	fetchETHEDiscount(false);

	fetchHashRateDiscount(false);

	fetchAssetVolumeData(false);
}

/**
 * @param {string} exchange
 * @param {Map} assetVolMap
 * @param {Number} attempt
 * @returns {Map} assetVolMap
 */
async function getAssetLatest(exchange, assetVolMap, attempt = 0) {
	try {
		attempt++;
		const url = AMBERDATA_BASE_URL + `metrics/exchanges/${exchange}/assets/volumes/latest?quoteVolume=false&direction=desc`;
		if (verbose) console.log(url);
		const amberdataJSON = await fetchAmberdataJson(url);
		const amberdata = amberdataJSON.payload.data;
		for (const item of amberdata) {
			if (assetVolMap.has(item.asset)) {
				const oldValue = assetVolMap.get(item.asset);
				assetVolMap.set(item.asset, oldValue + Number(item.volumeUSD));
			}
		}

		return assetVolMap;
	}
	catch (err) {
		console.log(attempt, err);
		if (attempt <= MAX_RETRIES) {
			return getAssetLatest(exchange, assetVolMap);
		}
		else {
			console.log('Bad request on getting volumes - bugging out', attempt);
			return assetVolMap;
		}
	}
}

/**
 * @param {string} exchange
 * @param {Map} assetVolMap
 * @param {Number} attempt
 * @returns {Map} assetVolMap
 */
async function getAssetHistoric(exchange, asset, startTime, assetVolMap, attempt = 0) {
	let amberdataJSON;
	let url;
	try {
		attempt++;
		url = AMBERDATA_BASE_URL + `metrics/exchanges/${exchange}/assets/volumes/historical?asset=${asset}&quoteVolume=false&startDate=${startTime}`;
		if (verbose) console.log(url);
		amberdataJSON = await fetchAmberdataJson(url);
		if (!amberdataJSON) {
			return assetVolMap;
		}
		const amberdata = amberdataJSON.payload.data;
		for (const item of amberdata) {
			if (assetVolMap.has(item.asset)) {
				const oldValue = assetVolMap.get(item.asset);
				assetVolMap.set(item.asset, oldValue + Number(item.volumeUSD));
			}
		}

		return assetVolMap;
	}
	catch (err) {
		console.log(attempt, err, url);
		if (attempt <= MAX_RETRIES) {
			return getAssetHistoric(exchange, asset, startTime, assetVolMap, attempt);
		}
		else {
			console.log('Bad request on getting volumes - bugging out', attempt);
			return assetVolMap;
		}
	}
}

async function fetchAssetVolumeData(sendCard = true) {
	let assetVolumeMap = new Map();
	for (const token of config.volumes.tokens) {
		assetVolumeMap.set(token, 0);
	}
	for (const exchange of config.volumes.exchanges) {
		console.log(exchange);
		assetVolumeMap = await getAssetLatest(exchange, assetVolumeMap);
	}


	for (const [asset, volume] of assetVolumeMap.entries()) {
		console.log(asset, '\t', lrgDollarUS.format(volume));
	}
	const liveTimestamp = new Date();
	const historicTimeStamp = liveTimestamp.getTime() - (86400000 * (Number(config.volumes.lookback) + 1));
	console.log(historicTimeStamp);
	let historicVolumeMap = new Map();
	for (const token of config.volumes.tokens) {
		historicVolumeMap.set(token, 0);
	}

	for (const exchange of config.volumes.exchanges) {
		console.log(exchange);
		for (const token of config.volumes.tokens) {
			console.log(token);
			historicVolumeMap = await getAssetHistoric(exchange, token, historicTimeStamp, historicVolumeMap);
		}
	}

	let outputStr = 'asset\t24hr\t7d (Av.) Volumes\r\n';
	for (const [asset, volume] of historicVolumeMap.entries()) {
		outputStr += '- ' + asset + '\t' + lrgDollarUS.format(assetVolumeMap.get(asset)) + '\t/\t' + lrgDollarUS.format(volume / Number(config.volumes.lookback)) + '\r\n';
	}

	console.log(outputStr);
	if (sendCard) await sendMessageToChannel('Trading Volumes', outputStr, 'https://www.coinglass.com/');
}

async function fetchGBTCDiscount(send = true) {
	const html = await fetchHtml(GBTC_DISCOUNT_URL);

	// const reg = /<span class="page-name-date">(.*)<\/span>/;
	const reg = /<span class="key-stat-title">\s*2\.00%\s*<\/span>\s*<\/td>\s*<td>\s*<span class="key-stat-title">\s*(.*%)\s*<\/span>/;
	const split = html.data.split(reg);

	const output = 'GBTC Discount\r\n' + split[1] + '%';

	if (send) {
		sendMessageToChannel('GBTC Discount', output, GBTC_DISCOUNT_URL);
	}
	console.log(new Date().toISOString(), output);
}

async function fetchETHEDiscount(send = true) {
	const html = await fetchHtml(ETHE_DISCOUNT_URL);

	// const reg = /<span class="page-name-date">(.*)<\/span>/;
	const reg = /<span class="key-stat-title">\s*2\.50%\s*<\/span>\s*<\/td>\s*<td>\s*<span class="key-stat-title">\s*(.*%)\s*<\/span>/;
	const split = html.data.split(reg);

	const output = 'ETHE Discount\r\n' + split[1] + '%';

	if (send) {
		sendMessageToChannel('ETHE Discount', output, ETHE_DISCOUNT_URL);
	}
	console.log(new Date().toISOString(), output);
}

async function fetchHashRateDiscount(send = true) {
	const json = await fetchJson(HASHRATE_URL);

	const output = '\r\n- HashRate: ' + exaHash.format(json[0].network_hashrate) + 'H/s\r\n' +
		'- Difficulty: ' + exaHash.format(json[0].difficulty) + '\r\n' +
		'- Price: ' + dollarUS.format(json[0].price) + '\r\n' +
		'- 24hr Volume: ' + lrgDollarUS.format(json[0].volume) + '\r\n';

	if (send) {
		sendMessageToChannel('MinerStats', output, 'https://minerstat.com/coin/BTC/difficulty');
	}
	console.log(new Date().toISOString(), output);
}

async function fetchHtml(url) {
	const resp = await axios.get(url, axiosConfig);
	return resp;
}

/**
 * Query Amberdata for liquidation data
 * @param {string} instrument
 * @param {Number} start
 * @param {Number} end
 * @param {Number=} threshold
 * @return {string | null} null if sum(abs(liquidations)) < threshold else string result
 */
async function getLiquidations(instrument, start, end, threshold = 0) {
	const url = AMBERDATA_BASE_URL + `futures/liquidations/${instrument}/historical?startDate=${start}&endDate=${end}`;
	if (verbose) console.log(url);
	const amberdataJSON = await fetchAmberdataJson(url);
	let amberdata;
	try {
		amberdata = amberdataJSON.payload.data;
	}
	catch (err) {
		console.log(instrument, err);
		return null;
	}
	let verbosOutputStr = instrument + `\n\nDirection${delim}B/S${delim}Exchange${delim}Qty${delim}Price${delim}MV${delim}Time\n`;
	const longLiq = {
		qty: 0,
		mv: 0,
	};

	const shortLiq = {
		qty: 0,
		mv: 0,
	};
	for (const liq of amberdata) {
		if (liq.positionType == 'LONG') {
			longLiq.qty += liq.volume;
			longLiq.mv += liq.volume * liq.price;
		}
		else if (liq.positionType == 'SHORT') {
			shortLiq.qty += liq.volume;
			shortLiq.mv += liq.volume * liq.price;
		}
		else {
			console.log('UKNOWN:', liq.positionType);
		}
		if (verbose) {
			verbosOutputStr += liq.positionType + delim +
				liq.side + delim +
				liq.exchange + delim +
				liq.volume + delim +
				liq.price + delim +
				dollarUS.format(liq.volume * liq.price) + delim +
				new Date(liq.timestamp).toISOString() + '\n';
		}
	}

	let outputString = '- ' + instrument + ' Summary (last ' + Math.floor((end - start) / 60000) + ' minutes):';
	if (longLiq.mv > 0 || shortLiq.mv > 0) {
		outputString += '\r\nLongs liquidated: ' + dollarUS.format(longLiq.mv) +
		' / ' + longLiq.qty + ' @ ' +
		dollarUS.format(longLiq.mv / longLiq.qty) +
		'\r\nShorts Liquidated: ' + dollarUS.format(shortLiq.mv) +
		' / ' + shortLiq.qty + ' @ ' +
		dollarUS.format(shortLiq.mv / shortLiq.qty) + '\r\n';

		if (verbose) console.log(verbosOutputStr);
	}
	else {
		outputString += 'NONE\r\n';
	}

	return ((shortLiq.mv + longLiq.mv) >= threshold) ? outputString : null;
}

/**
 * Query Amberdata for funding rates data
 * @param {string} instrument
 */
async function getFundingRates(instrument, attempt = 0) {
	try {

		const url = AMBERDATA_BASE_URL + `futures/funding-rates/${instrument}/latest`;
		if (verbose) console.log(url);
		const amberdataJSON = await fetchAmberdataJson(url);
		const amberdata = amberdataJSON.payload[0];
		// =((1+ABS(K6))^(24/8*365)-1)
		const fundingRate = Number(amberdata.fundingRate);
		const sign = fundingRate ? fundingRate < 0 ? -1 : 1 : 0;
		const annualisedRate = sign * (Math.pow(1 + Math.abs(fundingRate), (24 / 8 * 365)) - 1);

		return '- ' + instrument + delim +
		// '@' + amberdata.exchange + delim +
		perc.format(amberdata.fundingRate) + '/' + perc.format(annualisedRate) + '\r';
		/*
		'From: ' + new Date(amberdata.fundingTime).toISOString() + delim +
		'To: ' + new Date(amberdata.nextFundingTime).toISOString() + delim +
		((amberdata.nextFundingTime - amberdata.fundingTime) / 60000).toFixed(1) + 'mins\n';
		*/
	}
	catch (err) {
		if (attempt <= MAX_RETRIES) {
			return getFundingRates(instrument, attempt++);
		}
		else {
			console.log('Bad request - bugging out', instrument, attempt);
			return '';
		}
	}
}

/**
 * Query Amberdata for funding rates data
 * @param {string} protocol
 * @param {string} token
 */
async function getLendingData(protocol, token, attempt = 0) {
	try {
		const url = AMBERDATA_NEW_BASE_URL + `defi/lending/assets/information?blockchain=ethereum-mainnet&protocol=${protocol}&asset=${token}`;
		if (verbose) console.log(url);
		const amberdataJSON = await fetchAmberdataJson(url);
		const amberdata = amberdataJSON.payload[0];
		console.log(amberdata);

		return '- ' + token + '@' + protocol + delim +
		// removing TVL:  + '/' + dollarUS.format(amberdata.tvl)
		perc2dp.format(amberdata.lendRate) + '/' + perc2dp.format(amberdata.borrowRateVariable) + '/' + perc2dp.format(amberdata.borrowRateStable) + '\r\n';
	}
	catch (err) {
		if (attempt <= MAX_RETRIES) {
			return getLendingData(protocol, token, attempt++);
		}
		else {
			console.log('Bad request - bugging out', protocol, token, attempt);
			return '';
		}
	}
}

/**
 * Helper method to check an argument flag is present
 * @param {string} arg
 * @returns {boolean}
 */
function getArgFlag(arg) {
	const customIndex = process.argv.indexOf(`-${arg}`);

	if (customIndex > -1) {
		return true;
	}

	return false;
}

/**
 * Send adaptive cards.
 */
// eslint-disable-next-line no-unused-vars
async function sendMessageToChannel(title, description, url) {
	new WebhookTarget(new URL(webhookUrl)).sendAdaptiveCard(
		AdaptiveCards.declare(template).render(
			{
				'title': title,
				'appName': 'Market Data Bot',
				'description': description,
				'notificationUrl' : url,
			}))
		.then(() => console.log('Send adaptive card successfully.'))
		.catch(e => console.log(`Failed to send adaptive card. ${e}`));
}

/**
 * Helper function to retrieve JSON from REST API
 * @param {string} url
 * @param {number} depth
 * @param {number} retries
 * @returns {*}
 */
async function fetchAmberdataJson(url, depth = 0, retries = MAX_RETRIES) {
	if (depth >= retries) return null;
	depth++;
	try {
		const res = await fetchWithTimeout(url, {
			headers: {
				'accept': 'application/json',
				'x-api-key': amberdataApiKey,
			},
		});

		if (res.status != 200) {
			const respJson = await res.json();
			// console.log('msg:', respJson);
			if (respJson.message == 'No assets found for the specified exchange.') {
				return null;
			}
			await sleep(1000 * depth);
			console.log(res.status, res.headers);
			return await fetchAmberdataJson(url, depth);
		}
		return await res.json();

	}
	catch (err) {
		console.log('fetch json error', url, depth, err);
		await sleep(500 * depth);
		return await fetchAmberdataJson(url, depth);
	}
}

/**
 * Helper function to retrieve JSON from REST API
 * @param {string} url
 * @param {number} depth
 * @param {number} retries
 * @returns {*}
 */
async function fetchJson(url, depth = 0, retries = MAX_RETRIES) {
	if (depth >= retries) return null;
	depth++;
	try {
		const res = await fetchWithTimeout(url);
		if (res.status != 200) {
			await sleep(500 * depth);
			return await fetchJson(url, depth);
		}
		return res.json();

	}
	catch (err) {
		await sleep(500 * depth);
		return await fetchJson(url, depth);
	}
}


/**
 * basci sleep function
 * @param {numer} ms milliseconds to sleep
 * @returns {Promise}
 */
function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Wrapper to fetch to implement a timeout
 * @param {string} resource
 * @param {*} options
 * @returns {Response}
 */
async function fetchWithTimeout(resource, options = {}) {
	const { timeout = 60000 } = options;

	const controller = new AbortController();
	const id = setTimeout(() => controller.abort(), timeout);
	const response = await fetch(resource, {
		...options,
		signal: controller.signal,
	});
	clearTimeout(id);
	return response;
}

main()
	.then()
	.catch(error => {
		console.error(error);
		process.exit(1);
	});