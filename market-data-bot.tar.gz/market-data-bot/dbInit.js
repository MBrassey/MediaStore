require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { exit } = require('process');
const Sequelize = require('sequelize');
const excludeFiles = [path.basename(__filename), 'index.js'];
const modelPath = path.join(__dirname, 'models');
const env = process.env.NODE_ENV || 'development';
const config = require('~config/dbConfig.json')[env];
const { infoLogger } = require('~utils/logger');
const db = {};

let sequelize;
if (config.use_env_variable) {
	sequelize = new Sequelize(process.env[config.use_env_variable], config);
}
else {
	sequelize = new Sequelize(config.database, config.username, config.password, config);
}

fs
	.readdirSync(modelPath)
	.filter(file => {
		return (file.indexOf('.') !== 0) && (!excludeFiles.includes(file)) && (file.slice(-3) === '.js');
	})
	.forEach(file => {
		try {
			const model = require(path.join(modelPath, file))(sequelize, Sequelize.DataTypes);
			db[model.name] = model;
		}
		catch (err) {
			infoLogger.error('error processing', path.join(modelPath, file), err);
		}
	});

Object.keys(db).forEach(modelName => {
	if (db[modelName].associate) {
		db[modelName].associate(db);
	}
});

console.log('Using ENV', env);

db.sequelize = sequelize;
db.Sequelize = Sequelize;

if (process.argv.includes('-h')) {
	console.log('node dbinit.js [--force] [--alter]');
	console.log('	--force		drop then recreate **WARNING DATA LOSS**');
	console.log('	--alter		update in place **CHECK INTEGRITY AFTER**');
	exit(0);
}

const force = process.argv.includes('--force') || process.argv.includes('-f');
const alter = process.argv.includes('--alter') || process.argv.includes('-a');

if (force && alter) {
	console.log('Pick FORCE or ALTER!!');
	exit(1);
}

sequelize.sync({ force: force, alter: alter }).then(async () => {
	console.log('Database synced');

	sequelize.close();
}).catch(console.error);